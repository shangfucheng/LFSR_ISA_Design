Everything works properly, You only need to change the file address in "InstRom.sv" to fetch
the machine code file "Machine3". other than that everything should be good.