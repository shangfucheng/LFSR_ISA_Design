Everything works properly. The code in "Code_for_both_program" works 
for all 3 programs, you only need to change the file path in "InstRom.sv" to
fetch the coresponding machine code that stores in each program 
folder( Machine5.txt, Machine6.txt).
Assembly code, machine code, testbench and transcript screenshot all stored in 
each program folder, "complier" is the python code that complies assembly to 
machine code. 
